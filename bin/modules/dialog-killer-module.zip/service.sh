#!/system/bin/sh
# ============================================================
#  Magisk Dialog Auto-Dismiss v2.0??????????
#  ? ???pidof ? 0.05s
#  ? App ? ? ? sleep ???????? 66ms?
#  ? ? cmd input keyevent 4??? 58ms??? Java ? input 937ms?
#  ? ??????0.15s ????????????????????
#  ? ??????"???"???
# ============================================================
LOGF=/data/adb/dialog_killer.log
chk() {
  dumpsys window windows 2>/dev/null | grep 'Window #' | grep topjohnwu | grep -v Splash | head -2 | wc -l
}
(
  echo "[$(date +%s%N)] v2.0 started" >> "$LOGF"
  while true; do
    if ! pidof com.topjohnwu.magisk >/dev/null 2>&1; then
      sleep 0.05
      continue
    fi
    n=$(chk)
    if [ "$n" -ge 2 ]; then
      echo "[$(date +%s%N)] dialog detected" >> "$LOGF"
      cnt=0
      while [ "$cnt" -lt 12 ]; do
        cmd input keyevent 4
        cnt=$((cnt+1))
        echo "[$(date +%s%N)] BACK #$cnt" >> "$LOGF"
        sleep 0.15
        n=$(chk)
        if [ "$n" -lt 2 ]; then
          sleep 0.1
          n=$(chk)
          [ "$n" -lt 2 ] && break
        fi
      done
      echo "[$(date +%s%N)] cleared (BACK x$cnt)" >> "$LOGF"
      sleep 1
    fi
  done
) &